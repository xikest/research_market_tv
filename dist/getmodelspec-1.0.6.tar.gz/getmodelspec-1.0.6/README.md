# getModelSpecForTV
 get specs for models of TV, for reseach
